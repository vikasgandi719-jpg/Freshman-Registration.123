import React, { useState } from "react";
import {
  View,
  Text,
  FlatList,
  StyleSheet,
  SafeAreaView,
  TouchableOpacity,
  Clipboard,
  Alert,
  TextInput,
} from "react-native";
import Header from "../../components/common/Header";
import { generateDemoCredentials } from "../../constants/demoCredentials";
import { ADMIN_ROLE_COLORS } from "../../constants/adminRoles";

const roleColorMap = {
  "Super Admin": ADMIN_ROLE_COLORS.super_admin,
  Principal: ADMIN_ROLE_COLORS.principal,
  "Branch Admin": ADMIN_ROLE_COLORS.branch_admin,
  "Verification Officer": ADMIN_ROLE_COLORS.verification_officer,
  Verifier: ADMIN_ROLE_COLORS.verifier,
};

const ALL_CREDENTIALS = generateDemoCredentials();

const CredentialsScreen = ({ navigation }) => {
  const [search, setSearch] = useState("");
  const [filterRole, setFilterRole] = useState("All");

  const roles = [
    "All",
    "Super Admin",
    "Principal",
    "Branch Admin",
    "Verification Officer",
    "Verifier",
  ];

  const filtered = ALL_CREDENTIALS.filter((c) => {
    const roleMatch = filterRole === "All" || c.role === filterRole;
    const searchMatch =
      !search ||
      c.name.toLowerCase().includes(search.toLowerCase()) ||
      c.email.toLowerCase().includes(search.toLowerCase()) ||
      c.branch.toLowerCase().includes(search.toLowerCase());
    return roleMatch && searchMatch;
  });

  const copyToClipboard = (text) => {
    Clipboard.setString(text);
    Alert.alert("Copied", `"${text}" copied to clipboard`);
  };

  const renderItem = ({ item }) => {
    const color = roleColorMap[item.role] || ADMIN_ROLE_COLORS.viewer;
    return (
      <View style={styles.card}>
        <View style={styles.cardHeader}>
          <View style={[styles.badge, { backgroundColor: color.bg }]}>
            <Text style={[styles.badgeText, { color: color.text }]}>
              {item.role}
            </Text>
          </View>
          <Text style={styles.branchTag}>{item.branch}</Text>
        </View>

        <Text style={styles.name}>{item.name}</Text>

        <View style={styles.credRow}>
          <View style={styles.credInfo}>
            <Text style={styles.credLabel}>Email</Text>
            <Text style={styles.credValue}>{item.email}</Text>
          </View>
          <TouchableOpacity
            style={styles.copyBtn}
            onPress={() => copyToClipboard(item.email)}
          >
            <Text style={styles.copyBtnText}>Copy</Text>
          </TouchableOpacity>
        </View>

        <View style={styles.divider} />

        <View style={styles.credRow}>
          <View style={styles.credInfo}>
            <Text style={styles.credLabel}>Password</Text>
            <Text style={styles.credValue}>{item.password}</Text>
          </View>
          <TouchableOpacity
            style={styles.copyBtn}
            onPress={() => copyToClipboard(item.password)}
          >
            <Text style={styles.copyBtnText}>Copy</Text>
          </TouchableOpacity>
        </View>
      </View>
    );
  };

  return (
    <SafeAreaView style={styles.safe}>
      <Header
        title="Login Credentials"
        subtitle={`${filtered.length} accounts`}
        onBack={() => navigation.goBack()}
      />

      <View style={styles.filters}>
        <TextInput
          style={styles.searchInput}
          placeholder="Search by name, email or branch..."
          value={search}
          onChangeText={setSearch}
        />
        <FlatList
          horizontal
          data={roles}
          keyExtractor={(item) => item}
          showsHorizontalScrollIndicator={false}
          renderItem={({ item: role }) => (
            <TouchableOpacity
              style={[
                styles.chip,
                filterRole === role && styles.chipActive,
              ]}
              onPress={() => setFilterRole(role)}
            >
              <Text
                style={[
                  styles.chipText,
                  filterRole === role && styles.chipTextActive,
                ]}
              >
                {role}
              </Text>
            </TouchableOpacity>
          )}
        />
      </View>

      <FlatList
        data={filtered}
        keyExtractor={(item) => item.email}
        renderItem={renderItem}
        contentContainerStyle={styles.list}
        showsVerticalScrollIndicator={false}
        ListEmptyComponent={
          <View style={styles.centered}>
            <Text style={styles.emptyText}>No credentials found.</Text>
          </View>
        }
      />
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: "#F8FAFC" },
  filters: {
    padding: 16,
    backgroundColor: "#FFF",
    borderBottomWidth: 1,
    borderBottomColor: "#E2E8F0",
    gap: 12,
  },
  searchInput: {
    backgroundColor: "#F1F5F9",
    borderRadius: 8,
    padding: 10,
    fontSize: 14,
  },
  chip: {
    paddingHorizontal: 14,
    paddingVertical: 6,
    borderRadius: 20,
    backgroundColor: "#F1F5F9",
    marginRight: 8,
  },
  chipActive: { backgroundColor: "#1D4ED8" },
  chipText: { fontSize: 12, color: "#64748B" },
  chipTextActive: { color: "#FFF", fontWeight: "600" },
  list: { padding: 16 },
  card: {
    backgroundColor: "#FFF",
    borderRadius: 12,
    marginBottom: 12,
    padding: 14,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.06,
    shadowRadius: 8,
    elevation: 2,
  },
  cardHeader: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 8,
    gap: 8,
  },
  badge: {
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: 12,
  },
  badgeText: { fontSize: 11, fontWeight: "600" },
  branchTag: { fontSize: 12, color: "#64748B" },
  name: {
    fontSize: 16,
    fontWeight: "700",
    color: "#1E293B",
    marginBottom: 12,
  },
  credRow: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingVertical: 6,
  },
  credInfo: { flex: 1 },
  credLabel: { fontSize: 11, color: "#94A3B8", marginBottom: 2 },
  credValue: {
    fontSize: 13,
    color: "#1E293B",
    fontFamily: "monospace",
  },
  copyBtn: {
    backgroundColor: "#EFF6FF",
    paddingHorizontal: 12,
    paddingVertical: 5,
    borderRadius: 6,
  },
  copyBtnText: { fontSize: 12, color: "#1D4ED8", fontWeight: "600" },
  divider: {
    height: 1,
    backgroundColor: "#F1F5F9",
    marginVertical: 2,
  },
  centered: { alignItems: "center", paddingVertical: 60 },
  emptyText: { fontSize: 14, color: "#94A3B8" },
});

export default CredentialsScreen;