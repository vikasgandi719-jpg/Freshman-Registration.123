import { BRANCHES } from "./branches";

export const generateDemoCredentials = () => {
  const credentials = [];

  // Super Admin
  credentials.push({
    role: "Super Admin",
    name: "Super Admin",
    email: "super@bvritn.ac.in",
    password: "SuperAdmin@123",
    branch: "All Branches",
  });

  // Principals
  Array.from({ length: 3 }, (_, pIdx) => {
    credentials.push({
      role: "Principal",
      name: `Principal ${pIdx + 1}`,
      email: `principal_${pIdx + 1}@bvritn.ac.in`,
      password: `Principal${pIdx + 1}@123`,
      branch: "All Branches",
    });
  });

  // Branch Admins
  BRANCHES.forEach((branch) => {
    credentials.push({
      role: "Branch Admin",
      name: `${branch.shortName} Branch Admin`,
      email: `ba_${branch.id}@bvritn.ac.in`,
      password: `BranchAdmin_${branch.shortName}@123`,
      branch: branch.shortName,
    });
  });

  // Verification Officers
  Array.from({ length: 3 }, (_, vIdx) => {
    credentials.push({
      role: "Verification Officer",
      name: `Verification Officer ${vIdx + 1}`,
      email: `vo_${vIdx + 1}@bvritn.ac.in`,
      password: `VerifyOfficer${vIdx + 1}@123`,
      branch: "All Branches",
    });
  });

  // Verifiers
  Array.from({ length: 3 }, (_, vIdx) => {
    credentials.push({
      role: "Verifier",
      name: `Verifier ${vIdx + 1}`,
      email: `verifier_${vIdx + 1}@bvritn.ac.in`,
      password: `Verifier${vIdx + 1}@123`,
      branch: "All Branches",
    });
  });

  return credentials;
};
